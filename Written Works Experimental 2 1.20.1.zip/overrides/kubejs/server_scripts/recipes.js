ServerEvents.recipes(event => {
    event.remove({output: [
        "#forge:tools"
    ]})
})