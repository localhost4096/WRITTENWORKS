// block drop replacer

console.info('Now replacing block drops...')

//LootJS.modifiers( event => {
//    event
//        .addBlockModifier("minecraft:campfire")
//        .randomChance(0.5)
//        .replaceLoot("minecraft:coal", "minecraft:charcoal")
//})
